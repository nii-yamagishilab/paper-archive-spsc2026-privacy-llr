Score from VPC attacker challenge
https://www.voiceprivacychallenge.org/attacker/

[1] Natalia Tomashenko, Xiaoxiao Miao, Emmanuel Vincent, and Junichi Yamagishi. 2025. The first voiceprivacy attacker challenge. In ICASSP 2025-2025 IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), 2025. IEEE, 1–2.



